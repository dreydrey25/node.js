var http = require('http');

http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('19/09/23 Andrey Sousa Tristão');
}).listen(8001);
